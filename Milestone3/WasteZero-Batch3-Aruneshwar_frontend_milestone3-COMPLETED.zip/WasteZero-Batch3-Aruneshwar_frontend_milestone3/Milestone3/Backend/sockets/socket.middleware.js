// Backend/sockets/socket.middleware.js


const jwt = require('jsonwebtoken');
const User = require('../models/users.model');

const socketAuthMiddleware = async (socket, next) => {
  try {
    // 💡 Check both auth object AND query params.
    // The frontend sends `auth: { token: 'Bearer <jwt>' }` so we must strip
    // the "Bearer " prefix before passing to jwt.verify — it expects a raw JWT.
    // Mirror the same pattern used by auth.middleware.js's `protect`.
    let rawToken =
      socket.handshake.auth?.token ||
      socket.handshake.query?.token;

    if (!rawToken) {
      return next(new Error('Access denied. No token provided.'));
    }

    // Strip "Bearer " prefix if present (case-insensitive to be safe)
    if (rawToken.startsWith('Bearer ') || rawToken.startsWith('bearer ')) {
      rawToken = rawToken.split(' ')[1];
    }

    const decoded = jwt.verify(rawToken, process.env.JWT_SECRET);

    const user = await User.findById(decoded.id).select('-password').lean();

    if (!user) {
      return next(new Error('User no longer exists.'));
    }

    // Same shape used across every REST controller/middleware — socket
    // event handlers can rely on socket.user.id / socket.user.role exactly
    // the way controllers rely on req.user.id / req.user.role.
    socket.user = {
      ...user,
      id: user._id.toString(),
    };

    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return next(new Error('Token has expired.'));
    }

    if (error.name === 'JsonWebTokenError') {
      return next(new Error('Invalid token.'));
    }

    return next(new Error('Authentication failed.'));
  }
};

module.exports = socketAuthMiddleware;